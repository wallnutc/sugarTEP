import React ,{Components} from 'react';

function PAG2 () {
  return (
    <div style={{backgroundColor:"red"}}>
      <h1>React’s ecosystem aims to give users complete control over everything,
      without being tied to a any particular way of doing things.
Still, while some common patterns and conventions have been established recently,
one thing that the React community has stayed away from is standardizing a unified
project structure. PAGINA 2!</h1>
    </div>
  );
}

export default PAG2;
