import React, {Component} from 'react';
import './lecturer/styles/mainFrame.css';

class NotFound extends Component  {


    render(){
      return (
        <div >
<h2>404 NOT FOUND!!</h2>

          </div>


      );
    }

}

export default NotFound;
